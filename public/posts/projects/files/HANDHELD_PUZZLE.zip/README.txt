HANDHELD PUZZLE

by _ = F = _



Simple Puzzle Game.

1. Controls
- Move : ← ↓ ↑ →  
- Pass one turn : X  
- Teleport : Z  
- Restart : R  
- Quit : ESC  

2. My Works
- https://twitter.com/1F_works
- https://gamejolt.com/@F_works
- https://f-works.itch.io/

Good night. ;)